/* script.js - neon layered falling dots + typing + interaction */

/* TYPING (roles under name) */
(function typing(){
  const el = document.getElementById('typedText');
  const roles = ['Web Developer','UI/UX Designer','Creative Technologist'];
  let ri=0, ci=0, del=false;
  function tick(){
    const text = roles[ri];
    if(!del){ ci++; el.textContent = text.slice(0,ci); }
    else { ci--; el.textContent = text.slice(0,ci); }
    if(!del && ci===text.length){ del=true; setTimeout(tick,1000); return; }
    if(del && ci===0){ del=false; ri=(ri+1)%roles.length; }
    setTimeout(tick, del?50:110);
  }
  tick();
})();

/* SMOOTH REVEAL ON SCROLL */
(function reveal(){
  const obs = new IntersectionObserver((entries)=>{
    entries.forEach(e=>{
      if(e.isIntersecting) e.target.classList.add('visible');
    });
  }, {threshold:0.12});
  document.querySelectorAll('.section, .project-vertical, .skill.card, .panel-glow').forEach(n=>obs.observe(n));
})();

/* SCROLL TOP BUTTON */
const topBtn = document.getElementById('topBtn');
window.addEventListener('scroll', ()=> {
  topBtn.style.display = (window.scrollY > 300) ? 'block' : 'none';
});
topBtn.addEventListener('click', ()=> window.scrollTo({top:0,behavior:'smooth'}));

/* CONTACT FORM (demo) */
document.getElementById('contactForm').addEventListener('submit', function(e){
  e.preventDefault();
  const name = document.getElementById('fullname') ? document.getElementById('fullname').value : (document.getElementById('fullname') || {}).value;
  const nm = name || 'Friend';
  alert(`Thank you, ${nm}! Your message was sent (demo).`);
  e.target.reset();
});

/* PROJECT MODAL (simple) */
function openProjectModal(id){
  const modal = document.getElementById('projectModal');
  const title = document.getElementById('modalTitle');
  const desc = document.getElementById('modalDesc');
  const links = document.getElementById('modalLinks');
  links.innerHTML = '';
  if(id==='syllotrack'){
    title.textContent = 'SylloTrack';
    desc.textContent = 'SylloTrack centralizes syllabus management, teacher uploads, student access and HOD analytics.';
    links.appendChild(Object.assign(document.createElement('a'),{textContent:'Presentation',href:'#',className:'btn alt',style:'margin-right:8px'}));
  } else {
    title.textContent = 'Health & Wellness Prototype';
    desc.textContent = 'Figma prototype for a wellness app — onboarding, tracking, interaction flows.';
    const a = document.createElement('a'); a.href='https://core-front-29782208.figma.site'; a.target='_blank'; a.className='btn alt'; a.textContent='Open Prototype'; links.appendChild(a);
  }
  modal.classList.add('active'); modal.setAttribute('aria-hidden','false');
}
function closeProjectModal(){ const modal=document.getElementById('projectModal'); if(modal){modal.classList.remove('active'); modal.setAttribute('aria-hidden','true')} }

/* KEYBOARD accessibility for project cards */
document.addEventListener('DOMContentLoaded', ()=> {
  document.querySelectorAll('.project-vertical').forEach((el, idx) => {
    el.addEventListener('keydown', (ev)=> { if(ev.key==='Enter'){ openProjectModal(idx===0?'syllotrack':'wellness'); } });
  });
});

/* LAYERED FALLING DOTS CANVAS */
(function layeredDots(){
  const canvas = document.getElementById('bgCanvas');
  if(!canvas) return;
  const ctx = canvas.getContext('2d');
  let W = canvas.width = window.innerWidth;
  let H = canvas.height = window.innerHeight;

  const layers = [
    {count: Math.max(40, Math.round(W*H/200000)), size:[0.5,1.2], speed:[0.3,0.8], alpha:[0.12,0.22]}, // background small fast
    {count: Math.max(30, Math.round(W*H/380000)), size:[1.4,2.8], speed:[0.12,0.32], alpha:[0.22,0.36]}, // mid
    {count: Math.max(12, Math.round(W*H/900000)), size:[2.8,4.6], speed:[0.06,0.18], alpha:[0.28,0.5]} // foreground big slow
  ];
  const palette = ['#00f0ff','#8a4dff','#00ffad'];

  let particles = [];

  function rand(min,max){ return Math.random()*(max-min)+min }
  function init(){
    W = canvas.width = window.innerWidth; H = canvas.height = window.innerHeight;
    particles = [];
    layers.forEach((layer, li)=>{
      for(let i=0;i<layer.count;i++){
        particles.push({
          layer: li,
          x: Math.random()*W,
          y: Math.random()*H,
          r: rand(layer.size[0], layer.size[1]),
          speed: rand(layer.speed[0], layer.speed[1]),
          col: palette[Math.floor(Math.random()*palette.length)],
          alpha: rand(layer.alpha[0], layer.alpha[1]),
          drift: rand(-0.25,0.25)
        });
      }
    });
  }

  function draw(){
    ctx.clearRect(0,0,W,H);
    ctx.globalCompositeOperation = 'lighter';
    particles.forEach(p=>{
      ctx.beginPath();
      ctx.fillStyle = p.col;
      ctx.globalAlpha = p.alpha;
      ctx.shadowBlur = Math.max(8, p.r*6);
      ctx.shadowColor = p.col;
      ctx.arc(p.x, p.y, p.r, 0, Math.PI*2);
      ctx.fill();
      ctx.closePath();
      // tail/stream for a little motion feel
      ctx.beginPath();
      ctx.globalAlpha = Math.min(0.12, p.alpha*0.5);
      ctx.strokeStyle = p.col;
      ctx.lineWidth = Math.max(0.4, p.r*0.25);
      ctx.moveTo(p.x, p.y - p.r*2);
      ctx.lineTo(p.x - p.drift*6, p.y - p.r*8);
      ctx.stroke();
      ctx.closePath();

      p.y += p.speed;
      p.x += p.drift*0.4;
      if(p.y > H + 6) { p.y = -6; p.x = Math.random()*W; }
      if(p.x > W + 8) p.x = -8;
      if(p.x < -8) p.x = W + 8;
    });
    ctx.globalAlpha = 1;
    requestAnimationFrame(draw);
  }

  window.addEventListener('resize', ()=>{
    init();
  });

  init(); draw();
})();
